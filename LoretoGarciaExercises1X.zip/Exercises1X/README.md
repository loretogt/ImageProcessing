(All the following calls are inside the folder of the exercise)
Call exercise 11a: 
    python3 exercise_11a_flatzone.py exercise_11_a_input_01.txt exercise_11a_input_01.pgm  exercise_11a_output_01.pgm
    example : python3 exercise_11a_flatzone.py exercise_11_a_input_01.txt immed_gray_inv_20051218_frgr4.pgm  exercise_11a_output_01.pgm
              python3 exercise_11a_flatzone.py exercise_11_a_input_02.txt gran01_64_flatzone0_0.pgm  exercise_11a_output_02.pgm

Call exercise12a:
    python3 exercise_12a_fznumber.py exercise_12_a_input_01.txt exercise_12a_input_01.pgm  exercise_12a_output_01.txt
    example :  python3 exercise_12a_fznumber.py exercise_12_a_input_01.txt immed_gray_inv_20051218_thresh127.pgm  exercise_12a_output_01.txt
               python3 exercise_12a_fznumber.py exercise_12_a_input_01.txt immed_gray_inv.pgm  exercise_12a_output_02.txt

Call exercise13a:
    python3 exercise_13a_minimum.py exercise_13a_input_01.txt exercise_13a_input_01.pgm  exercise_13a_output_01.txt
    example :  python3 exercise_13a_minimum.py exercise_13a_input_01.txt immed_gray_inv_20051218_frgr4.pgm  exercise_13a_output_01.txt
               python3 exercise_13a_minimum.py exercise_13a_input_02.txt immed_gray_inv_20051218_frgr4.pgm  exercise_13a_output_02.txt

Call exercise13b:
    python3 exercise_13b_maximum.py exercise_13b_input_01.txt exercise_13b_input_01.pgm  exercise_13b_output_01.txt
    example :  python3 exercise_13b_maximum.py exercise_13b_input_01.txt immed_gray_inv_20051218_frgr4.pgm  exercise_13b_output_01.txt
               python3 exercise_13b_maximum.py exercise_13b_input_02.txt immed_gray_inv_20051218_frgr4.pgm  exercise_13b_output_02.txt

Call exercise13c: python3 exercise_13c_minima.py  exercise_13c_input_01.pgm  exercise_13c_output_01.png
    example : python3 exercise_13c_minima.py  immed_gray_inv_20051218_frgr4.pgm  exercise_13c_output_01.png
    
Call exercise13d: python3 exercise_13d_maxima.py  exercise_13c_input_01.pgm  exercise_13d_output_01.png
    example : python3 exercise_13d_maxima.py  immed_gray_inv_20051218_frgr4.pgm  exercise_13d_output_01.png